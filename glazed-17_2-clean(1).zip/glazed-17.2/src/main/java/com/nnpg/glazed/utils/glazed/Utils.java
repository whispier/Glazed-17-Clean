package com.nnpg.glazed.utils.glazed;

import org.joml.Vector3d;

import net.minecraft.world.phys.Vec3;

public final class Utils {

    public static void copyVector(Vector3d destination, Vec3 source) {
        destination.x = source.x;
        destination.y = source.y;
        destination.z = source.z;
    }

    public static void copyVector(Vector3d destination, Vector3d source) {
        destination.x = source.x;
        destination.y = source.y;
        destination.z = source.z;
    }

    public static Vector3d toVector3d(Vec3 vec3d) {
        return new Vector3d(vec3d.x, vec3d.y, vec3d.z);
    }

    public static Vec3 toVec3d(Vector3d vector3d) {
        return new Vec3(vector3d.x, vector3d.y, vector3d.z);
    }

    public static double lerp(double start, double end, double progress) {
        return start + (end - start) * progress;
    }

    public static Vector3d lerp(Vector3d start, Vector3d end, double progress) {
        return new Vector3d(
            lerp(start.x, end.x, progress),
            lerp(start.y, end.y, progress),
            lerp(start.z, end.z, progress)
        );
    }

    public static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    public static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    public static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
}
