Set-Location -Path $PSScriptRoot
Start-Transcript -Path (Join-Path $PSScriptRoot 'diagnose-log.txt') -Force | Out-Null
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.ServicePointManager]::SecurityProtocol } catch {}

Write-Host "`n===== 1/4  Java =====" -ForegroundColor Cyan
cmd /c "java -version 2>&1"
Write-Host "JAVA_HOME = $env:JAVA_HOME"

Write-Host "`n===== 2/4  DNS (what IPs does your PC get for the Fabric server?) =====" -ForegroundColor Cyan
try { Resolve-DnsName maven.fabricmc.net -ErrorAction Stop | Select-Object Name,Type,IPAddress | Format-Table -AutoSize | Out-Host }
catch { Write-Host "DNS FAILED: $($_.Exception.Message)" -ForegroundColor Red }

Write-Host "`n===== 3/4  Can this PC download what Gradle needs? =====" -ForegroundColor Cyan
$urls = @(
 'https://maven.fabricmc.net/fabric-loom/fabric-loom.gradle.plugin/1.15.5/fabric-loom.gradle.plugin-1.15.5.pom',
 'https://repo.maven.apache.org/maven2/org/apache/commons/commons-lang3/3.14.0/commons-lang3-3.14.0.pom',
 'https://plugins.gradle.org/m2/',
 'https://services.gradle.org/versions/current',
 'https://maven.meteordev.org/releases/',
 'https://jitpack.io/'
)
foreach ($u in $urls) {
  try {
    $r = Invoke-WebRequest -Uri $u -UseBasicParsing -TimeoutSec 40 -ErrorAction Stop
    Write-Host ("OK    HTTP {0}  {1}" -f $r.StatusCode, $u) -ForegroundColor Green
  } catch {
    $resp = $_.Exception.Response
    if ($resp) { Write-Host ("REACHED (HTTP {0})  {1}" -f [int]$resp.StatusCode, $u) -ForegroundColor Yellow }
    else { Write-Host ("FAILED  {0}`n        reason: {1}" -f $u, $_.Exception.Message) -ForegroundColor Red }
  }
}

Write-Host "`n===== 4/4  Gradle build (live output, this takes a few minutes) =====" -ForegroundColor Cyan
cmd /c "gradlew.bat --stop 2>&1"
cmd /c "gradlew.bat build --refresh-dependencies --stacktrace 2>&1"
Write-Host "`nGradle exit code: $LASTEXITCODE" -ForegroundColor Cyan
Stop-Transcript | Out-Null
Write-Host "`nSaved to diagnose-log.txt in this folder." -ForegroundColor Cyan
